PRANAV KANDEKAR - PORTFOLIO
1. Unzip the folder.
2. Put your photo in the folder and name it photo.jpg (square, face centred). Without it, your initials show.
3. Double-click index.html to open it in your browser (internet needed once for the Google Fonts).
4. Open script.js and fill in LINKS at the top (email, LinkedIn, GitHub). Empty links appear greyed out.
5. To publish free: upload the folder to GitHub Pages, Netlify or Vercel.
6. As you learn: edit the Projects section in index.html and add real projects and certificates.

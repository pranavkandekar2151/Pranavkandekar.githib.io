/* ===== EDIT YOUR LINKS HERE ===== */
const LINKS = {
  email: "",     // e.g. "pranav@gmail.com"
  linkedin: "",  // e.g. "https://linkedin.com/in/yourname"
  github: ""     // e.g. "https://github.com/yourname"
};
/* ================================ */

const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const calm = matchMedia("(prefers-reduced-motion: reduce)").matches;
$("#yr").textContent = new Date().getFullYear();

// Contact links
const setLink = (id, href, label) => {
  const el = $(id);
  if (href) { el.href = href; if (!href.startsWith("mailto")) el.target = "_blank"; el.rel = "noopener"; }
  else { el.classList.add("off"); el.removeAttribute("href"); el.title = "Add this link in script.js"; }
};
setLink("#lnEmail", LINKS.email && "mailto:" + LINKS.email);
setLink("#lnLinkedin", LINKS.linkedin);
setLink("#lnGithub", LINKS.github);
if (!LINKS.email && !LINKS.linkedin && !LINKS.github) $("#note").textContent = "Contact links are coming soon.";

// Typed line
const words = ["one line of code at a time.", "one dataset at a time.", "one project at a time."];
let w = 0, c = 0, del = false;
(function type() {
  const t = words[w], el = $("#typed");
  if (calm) { el.textContent = t; return; }
  el.textContent = t.slice(0, c);
  if (!del && c === t.length) { del = true; return setTimeout(type, 1500); }
  if (del && c === 0) { del = false; w = (w + 1) % words.length; }
  c += del ? -1 : 1;
  setTimeout(type, del ? 30 : 70);
})();

// Cursor glow + progress + active nav
addEventListener("pointermove", e => { $("#glow").style.left = e.clientX + "px"; $("#glow").style.top = e.clientY + "px"; });
const sections = $$("section, header");
addEventListener("scroll", () => {
  const h = document.documentElement;
  $("#progress").style.width = (scrollY / (h.scrollHeight - innerHeight) * 100) + "%";
  let cur = "hero";
  sections.forEach(s => { if (s.getBoundingClientRect().top < innerHeight * .4) cur = s.id; });
  $$("nav a").forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#" + cur && cur !== "hero"));
  drawCurve();
}, { passive: true });

// Reveal on scroll
$$(".wrap > *").forEach(e => e.classList.add("reveal"));
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .15 });
$$(".reveal").forEach(e => io.observe(e));
$$(".cards .card").forEach(c => { c.addEventListener("click", () => c.classList.toggle("flip")); c.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); c.classList.toggle("flip"); } }); });

// Loss curve drawn by scroll
const path = $("#curve"), len = path.getTotalLength(), eps = $$(".epoch");
path.style.strokeDasharray = len;
function drawCurve() {
  const r = $(".curve").getBoundingClientRect();
  const p = calm ? 1 : Math.min(1, Math.max(0, (innerHeight * .85 - r.top) / (r.height * 1.1)));
  path.style.strokeDashoffset = len * (1 - p);
  eps.forEach((e, i) => e.classList.toggle("show", p > i / eps.length + .05));
}
drawCurve();

// Neural network canvas
const cv = $("#net"), ctx = cv.getContext("2d");
let W, H, pts = [], mx = -999, my = -999;
function size() {
  W = cv.width = cv.offsetWidth; H = cv.height = cv.offsetHeight;
  const n = Math.min(90, Math.floor(W * H / 14000));
  pts = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35 }));
}
size(); addEventListener("resize", size);
cv.parentElement.addEventListener("pointermove", e => { const r = cv.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; });
cv.parentElement.addEventListener("pointerleave", () => { mx = my = -999; });
function frame() {
  ctx.clearRect(0, 0, W, H);
  for (const p of pts) {
    p.x += p.vx; p.y += p.vy;
    if (p.x < 0 || p.x > W) p.vx *= -1;
    if (p.y < 0 || p.y > H) p.vy *= -1;
    const dx = mx - p.x, dy = my - p.y, d = Math.hypot(dx, dy);
    if (d < 180) { p.x += dx * .012; p.y += dy * .012; }
  }
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    for (let j = i + 1; j < pts.length; j++) {
      const b = pts[j], d = Math.hypot(a.x - b.x, a.y - b.y);
      if (d < 130) { ctx.strokeStyle = `rgba(124,92,255,${(1 - d / 130) * .55})`; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
    }
    const near = Math.hypot(mx - a.x, my - a.y) < 180;
    ctx.fillStyle = near ? "#ff6b8a" : "#5ce1e6";
    ctx.beginPath(); ctx.arc(a.x, a.y, near ? 3.5 : 2.2, 0, 7); ctx.fill();
    if (near) { ctx.strokeStyle = "rgba(255,107,138,.5)"; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mx, my); ctx.stroke(); }
  }
  if (!calm) requestAnimationFrame(frame);
}
frame();

// Split headings into letters for font animation
$$("h1 span, h2").forEach(el => {
  const t = el.textContent; el.setAttribute("aria-label", t); el.textContent = "";
  [...t].forEach((c, i) => { const s = document.createElement("span"); s.className = "ch"; s.style.setProperty("--i", i); s.setAttribute("aria-hidden", "true"); s.textContent = c; el.appendChild(s); });
});
// Background colour shifts as you scroll
addEventListener("scroll", () => {
  const h = document.documentElement;
  h.style.setProperty("--hue", (scrollY / (h.scrollHeight - innerHeight) * 140) + "deg");
}, { passive: true });

// Photo tilt
const pw = $(".pwrap");
if (pw && !calm) {
  pw.addEventListener("pointermove", e => { const r = pw.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; pw.style.transform = `perspective(700px) rotateY(${x * 18}deg) rotateX(${-y * 18}deg)`; });
  pw.addEventListener("pointerleave", () => { pw.style.transform = ""; });
}

// Count-up numbers
const nio = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return; nio.unobserve(e.target);
  const el = e.target, to = +el.dataset.to, d = +el.dataset.dec, suf = el.dataset.suf;
  if (calm) return; const t0 = performance.now();
  (function step(t) { const p = Math.min(1, (t - t0) / 1600), v = to * (1 - Math.pow(1 - p, 3)); el.textContent = v.toFixed(d) + suf; if (p < 1) requestAnimationFrame(step); })(t0);
}), { threshold: .6 });
$$(".num").forEach(n => nio.observe(n));
